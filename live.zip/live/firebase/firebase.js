// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAf50p5GGV99c1dFxOcqp_c0frb-6snZ_Q",
  authDomain: "artifact-be47f.firebaseapp.com",
  projectId: "artifact-be47f",
  storageBucket: "artifact-be47f.appspot.com",
  messagingSenderId: "763119175670",
  appId: "1:763119175670:web:d44556c5b5a279f2d129d7",
  measurementId: "G-ZFMLD00GJ5",
  webClientId:"AIzaSyAGwl-v5-llQRhmBIZ8L7lHtsqyEeubW2g"

};
// Initialize Firebase
const app = initializeApp(firebaseConfig);